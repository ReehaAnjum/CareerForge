"""CareerForge automated tests."""
